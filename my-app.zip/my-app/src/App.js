import logo from './logo.svg';
import './App.css';
import Home from './Component/Home';
import Trains from './Component/Trains';
import Navbar from './Component/Navbar';
import { Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div>
      <Navbar/>

      <Routes>
        <Route path = "/" element = {<Home/>} />
        <Route path = "/trains" element = {<Trains/>} />
      </Routes>
    </div>
  );
}

export default App;
