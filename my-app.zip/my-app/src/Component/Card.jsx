import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom';

export default function Card({data,responsetrain}) {
    const navigate=  useNavigate()
    async function trainpath(){
        if(data.trainNumber ===responsetrain.trainNumber){
            navigate("/trains");
        }
    }

    

  return (
    <div>
        <div onClick={()=>trainpath()}>
            <h5>{data.trainName}</h5>
            <p>{data.trainNumber}</p>
        </div>
        <hr />
        <p>
            <span>{data.departureTime[0]}</span>
            <span>{data.departureTime[1]}</span>
            <span>{data.departureTime[2]}</span>
        </p>
        
        <div>
            <p>Seats Available :</p><br />
            <p>
                Sleeper :
                <span>{data.seatsAvailable[0]}</span>
            </p>
            <p>
                AC : 
                <span>{data.seatsAvailable[1]}</span>
            </p>
        </div>
        <div>
            <p>Price :</p><br />
            <p>
                Sleeper :
                <span>{data.price[0]}</span>
            </p>
            <p>
                AC :
                <span>{data.price[1]}</span>
            </p>
        </div>
        <p>
            Delayed by : <span>  {data.delayedBy}</span>
        </p>

    </div>
  )
}
