import React, { useEffect } from 'react'

export default function Trains({responsetrain}) {
    async function trainClickhandler(){
        alert("Already on the particular train page")
    }

    async function fetchTrainresponsetrain(){
        let requesttrain = await fetch("http://20.244.56.144:80/train/trains")
        let responsetrain  = await requesttrain.json()
        console.log(responsetrain);
    }

    useEffect(()=>{
        fetchTrainresponsetrain()
    },[])
  return (
    <div>
        <div onClick={()=>trainClickhandler()}>
            <h5>{responsetrain.trainName}</h5>
            <p>{responsetrain.trainNumber}</p>
        </div>
        <hr />
        <p>
            <span>{responsetrain.departureTime[0]}</span>
            <span>{responsetrain.departureTime[1]}</span>
            <span>{responsetrain.departureTime[2]}</span>
        </p>
        
        <div>
            <p>Seats Available :</p><br />
            <p>
                Sleeper :
                <span>{responsetrain.seatsAvailable[0]}</span>
            </p>
            <p>
                AC : 
                <span>{responsetrain.seatsAvailable[1]}</span>
            </p>
        </div>
        <div>
            <p>Price :</p><br />
            <p>
                Sleeper :
                <span>{responsetrain.price[0]}</span>
            </p>
            <p>
                AC :
                <span>{responsetrain.price[1]}</span>
            </p>
        </div>
        <p>
            Delayed by : <span>  {responsetrain.delayedBy}</span>
        </p>

    </div>
  )
}
