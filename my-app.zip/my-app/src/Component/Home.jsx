import React, { useEffect } from 'react'
import Card from './Card';

export default function Home(props) {

    async function fetchdata(){
        let request = await fetch("http://20.244.56.144:80/train/trains")
        let response  = await request.json()
        console.log(response);
    }

    useEffect(()=>{
        fetchdata()
    },[])


  return (
    <div>
        {
            response.map((data)=>{
            return   <Card key = {data.id} data={data}/>
        })
        }
    </div>
  )
}
