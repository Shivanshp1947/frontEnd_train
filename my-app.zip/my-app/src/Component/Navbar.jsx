import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'

export default function Navbar() {
    const navigate = useNavigate()
    async function homepath(){
        navigate("/")
        };
  return (
    <div className='flex items-center justify-center w-screen h-10
    bg-gray-800 text-white'>
        <nav>
            <NavLink to= "/">
                <p onClick={()=>homepath()}>
                    Home
                </p>
            </NavLink>

        </nav>
    </div>
  )
}
